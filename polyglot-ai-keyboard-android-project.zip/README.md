# Polyglot AI Keyboard (Native Android Studio Project)

Complete native Android InputMethodService keyboard project built with Kotlin & Jetpack Compose.

## Quick Start
1. Open this unzipped folder directly in Android Studio.
2. Click Build > Build Bundle(s) / APK(s) > Build APK(s).
3. Install app/build/outputs/apk/debug/app-debug.apk on your phone!