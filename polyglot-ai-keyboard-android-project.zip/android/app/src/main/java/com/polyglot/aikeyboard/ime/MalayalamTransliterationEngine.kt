package com.polyglot.aikeyboard.ime

object MalayalamTransliterationEngine {
    private val commonWords = mapOf(
        "namaskaram" to "നമസ്കാരം",
        "sugham" to "സുഖം",
        "sughamano" to "സുഖമാണോ",
        "nandi" to "നന്ദി",
        "evideya" to "എവിടെയാ",
        "kazhicho" to "കഴിച്ചോ",
        "sheri" to "ശരി"
    )

    fun transliterate(input: String): String {
        val trimmed = input.trim().lowercase()
        return commonWords[trimmed] ?: input
    }
}