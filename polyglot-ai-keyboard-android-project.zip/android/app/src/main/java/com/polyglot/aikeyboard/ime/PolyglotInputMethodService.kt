package com.polyglot.aikeyboard.ime

import android.content.Intent
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import androidx.compose.runtime.*
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.*
import androidx.savedstate.*
import com.polyglot.aikeyboard.api.TranslationApiClient
import com.polyglot.aikeyboard.ime.ui.ComposeKeyboardView
import com.polyglot.aikeyboard.ime.ui.TranslationTone
import com.polyglot.aikeyboard.ui.MainActivity
import kotlinx.coroutines.*

class PolyglotInputMethodService : InputMethodService(),
    LifecycleOwner,
    ViewModelStoreOwner,
    SavedStateRegistryOwner {

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateRegistryController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var apiClient: TranslationApiClient

    private var currentTextBuffer by mutableStateOf("")
    private var liveTranslatedText by mutableStateOf("")
    private var liveTransliteration by mutableStateOf<String?>(null)
    private var sourceLang by mutableStateOf("ml")
    private var targetLang by mutableStateOf("en")
    private var currentTone by mutableStateOf(TranslationTone.CASUAL)
    private var isTranslating by mutableStateOf(false)

    private var translationJob: Job? = null
    private val debounceHandler = Handler(Looper.getMainLooper())
    private var debounceRunnable: Runnable? = null

    override fun onCreate() {
        savedStateRegistryController.performRestore(null)
        super.onCreate()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        apiClient = TranslationApiClient(applicationContext)
    }

    override fun onCreateInputView(): View {
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        return ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@PolyglotInputMethodService)
            setViewTreeViewModelStoreOwner(this@PolyglotInputMethodService)
            setViewTreeSavedStateRegistryOwner(this@PolyglotInputMethodService)

            setContent {
                ComposeKeyboardView(
                    currentInputText = currentTextBuffer,
                    translatedText = liveTranslatedText,
                    transliteration = liveTransliteration,
                    sourceLang = sourceLang,
                    targetLang = targetLang,
                    selectedTone = currentTone,
                    isTranslating = isTranslating,
                    onKeyInput = { key -> handleKeyInput(key) },
                    onBackspace = { handleBackspace() },
                    onSpace = { handleSpace() },
                    onEnter = { handleEnter() },
                    onCommitTranslation = { translation -> commitTranslatedText(translation) },
                    onSwapLanguages = { swapLanguages() },
                    onToneChanged = { tone ->
                        currentTone = tone
                        triggerTranslation(currentTextBuffer)
                    },
                    onSwitchIme = { switchToNextIme() },
                    onOpenHub = { openLearningHub() }
                )
            }
        }
    }

    private fun handleKeyInput(key: String) {
        val ic = currentInputConnection ?: return
        ic.commitText(key, 1)
        currentTextBuffer += key
        scheduleTranslationDebounced()
    }

    private fun handleBackspace() {
        val ic = currentInputConnection ?: return
        ic.deleteSurroundingText(1, 0)
        if (currentTextBuffer.isNotEmpty()) {
            currentTextBuffer = currentTextBuffer.dropLast(1)
            scheduleTranslationDebounced()
        } else {
            liveTranslatedText = ""
            liveTransliteration = null
        }
    }

    private fun handleSpace() {
        val ic = currentInputConnection ?: return
        ic.commitText(" ", 1)
        currentTextBuffer += " "
        scheduleTranslationDebounced()
    }

    private fun handleEnter() {
        val ic = currentInputConnection ?: return
        val action = currentInputEditorInfo?.imeOptions ?: 0
        val actionId = action and EditorInfo.IME_MASK_ACTION

        if (actionId != EditorInfo.IME_ACTION_NONE && actionId != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(actionId)
        } else {
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }
        currentTextBuffer = ""
        liveTranslatedText = ""
    }

    private fun commitTranslatedText(textToInsert: String) {
        val ic = currentInputConnection ?: return
        ic.beginBatchEdit()
        if (currentTextBuffer.isNotEmpty()) {
            ic.deleteSurroundingText(currentTextBuffer.length, 0)
        }
        ic.commitText(textToInsert, 1)
        ic.commitText(" ", 1)
        ic.endBatchEdit()

        currentTextBuffer = ""
        liveTranslatedText = ""
        liveTransliteration = null
    }

    private fun swapLanguages() {
        val temp = sourceLang
        sourceLang = targetLang
        targetLang = temp
        triggerTranslation(currentTextBuffer)
    }

    private fun scheduleTranslationDebounced() {
        debounceRunnable?.let { debounceHandler.removeCallbacks(it) }
        debounceRunnable = Runnable { triggerTranslation(currentTextBuffer) }
        debounceHandler.postDelayed(debounceRunnable!!, 350)
    }

    private fun triggerTranslation(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) {
            liveTranslatedText = ""
            liveTransliteration = null
            isTranslating = false
            return
        }

        if (sourceLang == "ml" && !trimmed.any { it in 'ഀ'..'ൿ' }) {
            liveTransliteration = MalayalamTransliterationEngine.transliterate(trimmed)
        }

        translationJob?.cancel()
        translationJob = serviceScope.launch {
            isTranslating = true
            try {
                val res = apiClient.translate(
                    text = trimmed,
                    sourceLang = sourceLang,
                    targetLang = targetLang,
                    tone = currentTone.key
                )
                liveTranslatedText = res.translation
                if (res.transliteration != null) {
                    liveTransliteration = res.transliteration
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                isTranslating = false
            }
        }
    }

    private fun switchToNextIme() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            switchToNextInputMethod(false)
        } else {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }
    }

    private fun openLearningHub() {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        startActivity(intent)
    }
}