package com.polyglot.aikeyboard.ime.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class KeyboardLayoutMode { QWERTY_EN, MALAYALAM_SCRIPT, SYMBOLS_NUMBERS }

enum class TranslationTone(val key: String, val labelEn: String, val labelMl: String) {
    CASUAL("casual", "Casual", "കൂട്ടുകാരോട്"),
    FORMAL("formal", "Formal", "ഔദ്യോഗികം"),
    POLITE("polite", "Polite", "ആദരവോടെ"),
    BUSINESS("business", "Business", "ഓഫീസ്"),
    POETIC("poetic", "Poetic", "കാവ്യാത്മകം")
}

@Composable
fun ComposeKeyboardView(
    currentInputText: String,
    translatedText: String,
    transliteration: String?,
    sourceLang: String,
    targetLang: String,
    selectedTone: TranslationTone,
    isTranslating: Boolean,
    onKeyInput: (String) -> Unit,
    onBackspace: () -> Unit,
    onSpace: () -> Unit,
    onEnter: () -> Unit,
    onCommitTranslation: (String) -> Unit,
    onSwapLanguages: () -> Unit,
    onToneChanged: (TranslationTone) -> Unit,
    onSwitchIme: () -> Unit,
    onOpenHub: () -> Unit
) {
    var layoutMode by remember { mutableStateOf(KeyboardLayoutMode.MALAYALAM_SCRIPT) }
    var isShifted by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxWidth().background(Color(0xFF13141F))) {
        // Top Ribbon with AI Suggestions & USE button
        Surface(color = Color(0xFF1E1F30), modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (translatedText.isNotBlank()) translatedText else "Translation appears here...",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (!transliteration.isNullOrBlank()) {
                        Text(text = transliteration, color = Color(0xFF94A3B8), fontSize = 10.sp)
                    }
                }
                Button(
                    onClick = { onCommitTranslation(translatedText) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("USE", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}