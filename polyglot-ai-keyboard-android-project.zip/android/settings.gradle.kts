rootProject.name = "PolyglotAIKeyboard"
include(":app")